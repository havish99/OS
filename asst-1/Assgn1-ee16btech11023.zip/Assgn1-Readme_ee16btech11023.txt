Compile the program on a linux machine using the following command
g++ Assgn1-Src_ee16btech11023.cpp -lrt -o time

Run the program using the following command
./time <type a valid linux command> (Eg: ./time ls)
